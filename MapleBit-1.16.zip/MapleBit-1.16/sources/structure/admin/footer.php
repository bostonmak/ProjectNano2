<?php
if(basename($_SERVER["PHP_SELF"]) == "footer.php") {
    die("403 - Access Forbidden");
}
?>
						</div>
						<br/>
					</div>
				</div>
			</div>
			<footer>
				<div class="container">
				<hr/>
					<p class="text-center">Proudly powered by MapleBit | <a href="http://forum.ragezone.com/members/1333360872.html">greenelf(x) &raquo;</a></p><br/>
				</div>
			</footer>
		</div>
	</body>
</html>